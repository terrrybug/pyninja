"""PyNinja - The Ultimate Python Dependency Ninja"""

__version__ = "1.0.0"
